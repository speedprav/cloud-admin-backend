import express from "express";
import mongoose from "mongoose";
import axios from "axios";
import cheerio from "cheerio";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const bookSchema = new mongoose.Schema({
  title: String,
  price: String,
});

const Book = mongoose.model("Book", bookSchema);

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB error:", err));

app.get("/scrape", async (req, res) => {
  try {
    const response = await axios.get("http://books.toscrape.com/");
    const $ = cheerio.load(response.data);
    const books = [];

    $(".product_pod").each((i, el) => {
      const title = $(el).find("h3 a").attr("title");
      const price = $(el).find(".price_color").text();
      books.push({ title, price });
    });

    await Book.deleteMany({});
    await Book.insertMany(books);
    res.json({ message: "Scraping done", books });
  } catch (err) {
    res.status(500).json({ error: err.toString() });
  }
});

app.get("/books", async (req, res) => {
  const books = await Book.find();
  res.json(books);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
